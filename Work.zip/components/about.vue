<template>

    <div class="content">

        <h1 class="justify-content-center-text-center">About...</h1>

    </div>

</template>
